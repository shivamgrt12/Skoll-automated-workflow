Grace Community Church - Outreach Committee
Fall 2026 committee packet (archive copy)
-------------------------------------------
Contents: agenda, notes, and a reflection from the fall cycle.
Archive only. Rough tallies inside are NOT for FY close and NOT the
system of record. Money is reconciled in the official ledgers.
Timezone: America/New_York.
